# CGPA-in-java
 Q. write a program to calculate CGPA using marks of three subject (out of 100).
